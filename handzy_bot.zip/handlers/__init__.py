from handlers import client
from handlers import admin
from handlers import other


__all__ = ['client', 'admin', 'other']
