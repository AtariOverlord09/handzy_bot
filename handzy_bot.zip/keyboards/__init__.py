from keyboards import client_kb
from keyboards import client_inline

from keyboards import admin_kb, admin_inline_kb

__all__ = [
    'client_kb',
    'client_inline',
    'admin_kb',
    'admin_inline_kb',
]
